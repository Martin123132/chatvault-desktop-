import zipfile, os, sys
from pathlib import Path

try:
    import chardet  #  type: ignore
except ImportError:  # pragma: no cover
    chardet = None

text_exts = {".txt",".md",".py",".js",".ts",".json",".csv",".xml",".html",".htm",".yml",".yaml",".css",".sql",".ini",".cfg",".toml"}

here = Path(__file__).resolve().parent
root = here.parent  # GPT_DESKTOP

# If a zip name is passed as the first argument, use it; else pick the first .zip in this directory.
if len(sys.argv) > 1:
    zip_path = Path(sys.argv[1])
else:
    zips = list(here.glob("*.zip"))
    if not zips:
        raise SystemExit("No zip file found alongside the script. Pass a zip path as the first argument.")
    zip_path = zips[0]

if not zip_path.exists():
    raise SystemExit(f"Zip not found: {zip_path}")

out_path = root / "all_text.txt"

def is_text_ext(name: str) -> bool:
    return Path(name).suffix.lower() in text_exts

def decode_bytes(data: bytes) -> str:
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        if chardet is None:
            return data.decode("utf-8", errors="replace")
        enc = chardet.detect(data).get("encoding") or "utf-8"
        return data.decode(enc, errors="replace")

parts: list[str] = []
with zipfile.ZipFile(zip_path) as z:
    for info in z.infolist():
        if info.is_dir():
            continue
        name = info.filename
        data = z.read(name)
        if not is_text_ext(name):
            parts.append(f"\n\n----- {name} (skipped non-text) -----\n")
            continue
        text = decode_bytes(data)
        parts.append(f"\n\n----- {name} -----\n{text}")

out_path.write_text("".join(parts), encoding="utf-8")
print(f"wrote {out_path}")